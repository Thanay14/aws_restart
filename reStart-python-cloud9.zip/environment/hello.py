print("Hello, World")

