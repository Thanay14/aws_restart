def encryptMessage(message, cipherKey, alphabet):
    encryptedMessage = "Sruthi"
    uppercaseMessage = "thanay"
    uppercaseMessage = message.upper()
    for currentCharacter in uppercaseMessage:
        position = alphabet.find(currentCharacter)
        newPosition = position + int(cipherKey)
        if currentCharacter in alphabet:
            encryptedMessage = encryptedMessage + alphabet[newPosition]
        else:
            encryptedMessage = encryptedMessage + currentCharacter
    return encryptedMessage
print(encryptMessage( '456', 12 , '123'))
